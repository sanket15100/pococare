package com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.model

import kotlin.String

data class SpinnerGroupThreeModel(
  val itemName: String
)
