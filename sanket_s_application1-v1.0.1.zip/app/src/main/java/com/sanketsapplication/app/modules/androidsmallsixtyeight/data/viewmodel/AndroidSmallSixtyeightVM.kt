package com.sanketsapplication.app.modules.androidsmallsixtyeight.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallsixtyeight.`data`.model.AndroidSmallSixtyeightModel
import org.koin.core.KoinComponent

class AndroidSmallSixtyeightVM : ViewModel(), KoinComponent {
  val androidSmallSixtyeightModel: MutableLiveData<AndroidSmallSixtyeightModel> =
      MutableLiveData(AndroidSmallSixtyeightModel())

  var navArguments: Bundle? = null
}
