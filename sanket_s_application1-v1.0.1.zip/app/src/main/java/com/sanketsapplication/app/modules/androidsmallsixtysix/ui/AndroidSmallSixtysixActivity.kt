package com.sanketsapplication.app.modules.androidsmallsixtysix.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSixtysixBinding
import com.sanketsapplication.app.modules.androidsmallnineteen.ui.AndroidSmallNineteenActivity
import com.sanketsapplication.app.modules.androidsmallseventyone.ui.AndroidSmallSeventyoneActivity
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallsixtysix.`data`.viewmodel.AndroidSmallSixtysixVM
import com.sanketsapplication.app.modules.androidsmallsixtythree.ui.AndroidSmallSixtythreeActivity
import com.sanketsapplication.app.modules.androidsmallthirtynine.ui.AndroidSmallThirtynineActivity
import com.sanketsapplication.app.modules.androidsmalltwentyfive.ui.AndroidSmallTwentyfiveActivity
import com.sanketsapplication.app.modules.androidsmalltwentythree.ui.AndroidSmallTwentythreeActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallSixtysixActivity :
    BaseActivity<ActivityAndroidSmallSixtysixBinding>(R.layout.activity_android_small_sixtysix) {
  private val viewModel: AndroidSmallSixtysixVM by viewModels<AndroidSmallSixtysixVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallSixtysixVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.frameAndroidSmall.setOnClickListener {
      val destIntent = AndroidSmallThirtynineActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumndownload.setOnClickListener {
      val destIntent = AndroidSmallTwentyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowdown.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnSettings.setOnClickListener {
      val destIntent = AndroidSmallSeventyoneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnfacebook.setOnClickListener {
      val destIntent = AndroidSmallSixtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnedit.setOnClickListener {
      val destIntent = AndroidSmallNineteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumntrophy.setOnClickListener {
      val destIntent = AndroidSmallTwentythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SIXTYSIX_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSixtysixActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
