package com.sanketsapplication.app.modules.androidsmalltwentysix.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallTwentysixModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtListofnearby: String? =
      MyApp.getInstance().resources.getString(R.string.msg_list_of_nearby2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCurrentlocatio: String? =
      MyApp.getInstance().resources.getString(R.string.msg_current_locatio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDistance: String? = MyApp.getInstance().resources.getString(R.string.msg_nearest_pharmac)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMap: String? = MyApp.getInstance().resources.getString(R.string.lbl_map)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_new_life_hospit4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDuration: String? = MyApp.getInstance().resources.getString(R.string.lbl_15_minutes)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJeevikaHospita: String? =
      MyApp.getInstance().resources.getString(R.string.msg_jeevika_hospita2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_19_minutes)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtVaidehiHospita: String? =
      MyApp.getInstance().resources.getString(R.string.msg_vaidehi_hospita2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_22_minutes)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtManipalHospita: String? =
      MyApp.getInstance().resources.getString(R.string.msg_manipal_hospita2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_24_minutes)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSAKRAHospital: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sakra_hospital3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_24_minutes)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
