package com.sanketsapplication.app.modules.androidsmallfive.`data`.model

import kotlin.String

data class SpinnerGroupEightyThreeModel(
  val itemName: String
)
