package com.sanketsapplication.app.modules.androidsmallthirtynine.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtynineModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtConnecttoaDo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_connect_to_a_do)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGetdoctorson: String? =
      MyApp.getInstance().resources.getString(R.string.msg_get_doctors_on)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtConsultwitha: String? =
      MyApp.getInstance().resources.getString(R.string.msg_consult_with_a)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
