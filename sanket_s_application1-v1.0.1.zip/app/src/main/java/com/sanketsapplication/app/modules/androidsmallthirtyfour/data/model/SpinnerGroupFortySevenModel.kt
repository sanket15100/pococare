package com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model

import kotlin.String

data class SpinnerGroupFortySevenModel(
  val itemName: String
)
