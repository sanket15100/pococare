package com.sanketsapplication.app.modules.androidsmallfive.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallfive.`data`.model.AndroidSmallFiveModel
import com.sanketsapplication.app.modules.androidsmallfive.`data`.model.SpinnerGroupEightyThreeModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class AndroidSmallFiveVM : ViewModel(), KoinComponent {
  val androidSmallFiveModel: MutableLiveData<AndroidSmallFiveModel> =
      MutableLiveData(AndroidSmallFiveModel())

  var navArguments: Bundle? = null

  val spinnerGroupEightyThreeList: MutableLiveData<MutableList<SpinnerGroupEightyThreeModel>> =
      MutableLiveData()
}
