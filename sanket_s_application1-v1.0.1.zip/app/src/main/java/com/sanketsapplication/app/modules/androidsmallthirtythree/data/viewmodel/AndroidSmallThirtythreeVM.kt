package com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.model.AndroidSmallThirtythreeModel
import com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.model.SpinnerGroupFourModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class AndroidSmallThirtythreeVM : ViewModel(), KoinComponent {
  val androidSmallThirtythreeModel: MutableLiveData<AndroidSmallThirtythreeModel> =
      MutableLiveData(AndroidSmallThirtythreeModel())

  var navArguments: Bundle? = null

  val spinnerGroupFourList: MutableLiveData<MutableList<SpinnerGroupFourModel>> = MutableLiveData()
}
