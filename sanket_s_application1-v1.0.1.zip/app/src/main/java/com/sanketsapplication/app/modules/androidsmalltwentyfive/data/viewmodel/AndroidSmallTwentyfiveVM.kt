package com.sanketsapplication.app.modules.androidsmalltwentyfive.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmalltwentyfive.`data`.model.AndroidSmallTwentyfiveModel
import org.koin.core.KoinComponent

class AndroidSmallTwentyfiveVM : ViewModel(), KoinComponent {
  val androidSmallTwentyfiveModel: MutableLiveData<AndroidSmallTwentyfiveModel> =
      MutableLiveData(AndroidSmallTwentyfiveModel())

  var navArguments: Bundle? = null
}
