package com.sanketsapplication.app.modules.androidsmallseventytwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallseventytwo.`data`.model.AndroidSmallSeventytwoModel
import org.koin.core.KoinComponent

class AndroidSmallSeventytwoVM : ViewModel(), KoinComponent {
  val androidSmallSeventytwoModel: MutableLiveData<AndroidSmallSeventytwoModel> =
      MutableLiveData(AndroidSmallSeventytwoModel())

  var navArguments: Bundle? = null
}
