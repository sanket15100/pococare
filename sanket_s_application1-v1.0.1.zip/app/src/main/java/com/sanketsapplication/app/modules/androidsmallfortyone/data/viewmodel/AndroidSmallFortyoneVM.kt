package com.sanketsapplication.app.modules.androidsmallfortyone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallfortyone.`data`.model.AndroidSmallFortyoneModel
import org.koin.core.KoinComponent

class AndroidSmallFortyoneVM : ViewModel(), KoinComponent {
  val androidSmallFortyoneModel: MutableLiveData<AndroidSmallFortyoneModel> =
      MutableLiveData(AndroidSmallFortyoneModel())

  var navArguments: Bundle? = null
}
