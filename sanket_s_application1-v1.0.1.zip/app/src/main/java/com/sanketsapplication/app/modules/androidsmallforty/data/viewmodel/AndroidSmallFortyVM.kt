package com.sanketsapplication.app.modules.androidsmallforty.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallforty.`data`.model.AndroidSmallFortyModel
import org.koin.core.KoinComponent

class AndroidSmallFortyVM : ViewModel(), KoinComponent {
  val androidSmallFortyModel: MutableLiveData<AndroidSmallFortyModel> =
      MutableLiveData(AndroidSmallFortyModel())

  var navArguments: Bundle? = null
}
