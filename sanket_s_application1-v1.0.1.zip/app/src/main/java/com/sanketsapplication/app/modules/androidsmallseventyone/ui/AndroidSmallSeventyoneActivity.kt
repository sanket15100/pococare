package com.sanketsapplication.app.modules.androidsmallseventyone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSeventyoneBinding
import com.sanketsapplication.app.modules.androidsmallnineteen.ui.AndroidSmallNineteenActivity
import com.sanketsapplication.app.modules.androidsmallseventyone.`data`.viewmodel.AndroidSmallSeventyoneVM
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallsixtysix.ui.AndroidSmallSixtysixActivity
import com.sanketsapplication.app.modules.androidsmallsixtythree.ui.AndroidSmallSixtythreeActivity
import com.sanketsapplication.app.modules.androidsmalltwentyfive.ui.AndroidSmallTwentyfiveActivity
import com.sanketsapplication.app.modules.androidsmalltwentythree.ui.AndroidSmallTwentythreeActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallSeventyoneActivity :
    BaseActivity<ActivityAndroidSmallSeventyoneBinding>(R.layout.activity_android_small_seventyone)
    {
  private val viewModel: AndroidSmallSeventyoneVM by viewModels<AndroidSmallSeventyoneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallSeventyoneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearColumntrophy.setOnClickListener {
      val destIntent = AndroidSmallTwentythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnfacebook.setOnClickListener {
      val destIntent = AndroidSmallSixtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumndownload.setOnClickListener {
      val destIntent = AndroidSmallTwentyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnsettingsOne.setOnClickListener {
      val destIntent = AndroidSmallSixtysixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowdown.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnedit.setOnClickListener {
      val destIntent = AndroidSmallNineteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SEVENTYONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSeventyoneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
