package com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ListrecenthospitalRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtRecentHospital: String? =
      MyApp.getInstance().resources.getString(R.string.msg_recent_hospital)

)
