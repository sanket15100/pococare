package com.sanketsapplication.app.modules.androidsmalltwentyfour.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmalltwentyfour.`data`.model.AndroidSmallTwentyfourModel
import org.koin.core.KoinComponent

class AndroidSmallTwentyfourVM : ViewModel(), KoinComponent {
  val androidSmallTwentyfourModel: MutableLiveData<AndroidSmallTwentyfourModel> =
      MutableLiveData(AndroidSmallTwentyfourModel())

  var navArguments: Bundle? = null
}
