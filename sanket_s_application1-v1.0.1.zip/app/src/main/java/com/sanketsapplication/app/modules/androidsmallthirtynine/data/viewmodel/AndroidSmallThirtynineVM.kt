package com.sanketsapplication.app.modules.androidsmallthirtynine.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtynine.`data`.model.AndroidSmallThirtynineModel
import org.koin.core.KoinComponent

class AndroidSmallThirtynineVM : ViewModel(), KoinComponent {
  val androidSmallThirtynineModel: MutableLiveData<AndroidSmallThirtynineModel> =
      MutableLiveData(AndroidSmallThirtynineModel())

  var navArguments: Bundle? = null
}
