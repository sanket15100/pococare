package com.sanketsapplication.app.modules.androidsmallsixtysix.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallsixtysix.`data`.model.AndroidSmallSixtysixModel
import org.koin.core.KoinComponent

class AndroidSmallSixtysixVM : ViewModel(), KoinComponent {
  val androidSmallSixtysixModel: MutableLiveData<AndroidSmallSixtysixModel> =
      MutableLiveData(AndroidSmallSixtysixModel())

  var navArguments: Bundle? = null
}
