package com.sanketsapplication.app.modules.androidsmallsixtyeight.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSixtyeightBinding
import com.sanketsapplication.app.modules.androidsmallnineteen.ui.AndroidSmallNineteenActivity
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallsixtyeight.`data`.viewmodel.AndroidSmallSixtyeightVM
import com.sanketsapplication.app.modules.androidsmallsixtynine.ui.AndroidSmallSixtynineActivity
import com.sanketsapplication.app.modules.androidsmallsixtythree.ui.AndroidSmallSixtythreeActivity
import com.sanketsapplication.app.modules.androidsmalltwentyfive.ui.AndroidSmallTwentyfiveActivity
import com.sanketsapplication.app.modules.androidsmalltwentythree.ui.AndroidSmallTwentythreeActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallSixtyeightActivity :
    BaseActivity<ActivityAndroidSmallSixtyeightBinding>(R.layout.activity_android_small_sixtyeight)
    {
  private val viewModel: AndroidSmallSixtyeightVM by viewModels<AndroidSmallSixtyeightVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallSixtyeightVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearColumnfacebook.setOnClickListener {
      val destIntent = AndroidSmallSixtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumntrophy.setOnClickListener {
      val destIntent = AndroidSmallTwentythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguage.setOnClickListener {
      val destIntent = AndroidSmallSixtynineActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowarrowleft.setOnClickListener {
      val destIntent = AndroidSmallSixtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumndownload.setOnClickListener {
      val destIntent = AndroidSmallTwentyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnedit.setOnClickListener {
      val destIntent = AndroidSmallNineteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SIXTYEIGHT_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSixtyeightActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
