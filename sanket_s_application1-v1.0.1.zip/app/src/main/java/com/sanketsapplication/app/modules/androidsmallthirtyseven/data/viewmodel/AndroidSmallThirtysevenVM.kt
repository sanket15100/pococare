package com.sanketsapplication.app.modules.androidsmallthirtyseven.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtyseven.`data`.model.AndroidSmallThirtysevenModel
import org.koin.core.KoinComponent

class AndroidSmallThirtysevenVM : ViewModel(), KoinComponent {
  val androidSmallThirtysevenModel: MutableLiveData<AndroidSmallThirtysevenModel> =
      MutableLiveData(AndroidSmallThirtysevenModel())

  var navArguments: Bundle? = null
}
