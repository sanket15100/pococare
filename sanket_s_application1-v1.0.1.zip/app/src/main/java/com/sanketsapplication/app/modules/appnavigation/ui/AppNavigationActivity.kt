package com.sanketsapplication.app.modules.appnavigation.ui

import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAppNavigationBinding
import com.sanketsapplication.app.modules.androidsmalleight.ui.AndroidSmallEightActivity
import com.sanketsapplication.app.modules.androidsmalleighteen.ui.AndroidSmallEighteenActivity
import com.sanketsapplication.app.modules.androidsmallfive.ui.AndroidSmallFiveActivity
import com.sanketsapplication.app.modules.androidsmallforty.ui.AndroidSmallFortyActivity
import com.sanketsapplication.app.modules.androidsmallfortyone.ui.AndroidSmallFortyoneActivity
import com.sanketsapplication.app.modules.androidsmallfour.ui.AndroidSmallFourActivity
import com.sanketsapplication.app.modules.androidsmallnineteen.ui.AndroidSmallNineteenActivity
import com.sanketsapplication.app.modules.androidsmallone.ui.AndroidSmallOneActivity
import com.sanketsapplication.app.modules.androidsmallseven.ui.AndroidSmallSevenActivity
import com.sanketsapplication.app.modules.androidsmallseventeen.ui.AndroidSmallSeventeenActivity
import com.sanketsapplication.app.modules.androidsmallseventy.ui.AndroidSmallSeventyActivity
import com.sanketsapplication.app.modules.androidsmallseventyone.ui.AndroidSmallSeventyoneActivity
import com.sanketsapplication.app.modules.androidsmallseventytwo.ui.AndroidSmallSeventytwoActivity
import com.sanketsapplication.app.modules.androidsmallsix.ui.AndroidSmallSixActivity
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallsixtyeight.ui.AndroidSmallSixtyeightActivity
import com.sanketsapplication.app.modules.androidsmallsixtynine.ui.AndroidSmallSixtynineActivity
import com.sanketsapplication.app.modules.androidsmallsixtysix.ui.AndroidSmallSixtysixActivity
import com.sanketsapplication.app.modules.androidsmallsixtythree.ui.AndroidSmallSixtythreeActivity
import com.sanketsapplication.app.modules.androidsmallthirtyeight.ui.AndroidSmallThirtyeightActivity
import com.sanketsapplication.app.modules.androidsmallthirtyfive.ui.AndroidSmallThirtyfiveActivity
import com.sanketsapplication.app.modules.androidsmallthirtyfour.ui.AndroidSmallThirtyfourActivity
import com.sanketsapplication.app.modules.androidsmallthirtynine.ui.AndroidSmallThirtynineActivity
import com.sanketsapplication.app.modules.androidsmallthirtyone.ui.AndroidSmallThirtyoneActivity
import com.sanketsapplication.app.modules.androidsmallthirtyseven.ui.AndroidSmallThirtysevenActivity
import com.sanketsapplication.app.modules.androidsmallthirtysix.ui.AndroidSmallThirtysixActivity
import com.sanketsapplication.app.modules.androidsmallthirtythree.ui.AndroidSmallThirtythreeActivity
import com.sanketsapplication.app.modules.androidsmallthirtytwo.ui.AndroidSmallThirtytwoActivity
import com.sanketsapplication.app.modules.androidsmallthree.ui.AndroidSmallThreeActivity
import com.sanketsapplication.app.modules.androidsmalltwentyfive.ui.AndroidSmallTwentyfiveActivity
import com.sanketsapplication.app.modules.androidsmalltwentyfour.ui.AndroidSmallTwentyfourActivity
import com.sanketsapplication.app.modules.androidsmalltwentysix.ui.AndroidSmallTwentysixActivity
import com.sanketsapplication.app.modules.androidsmalltwentythree.ui.AndroidSmallTwentythreeActivity
import com.sanketsapplication.app.modules.androidsmalltwo.ui.AndroidSmallTwoActivity
import com.sanketsapplication.app.modules.appnavigation.`data`.viewmodel.AppNavigationVM
import kotlin.String
import kotlin.Unit

class AppNavigationActivity :
    BaseActivity<ActivityAppNavigationBinding>(R.layout.activity_app_navigation) {
  private val viewModel: AppNavigationVM by viewModels<AppNavigationVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appNavigationVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearAndroidSmallEighteen.setOnClickListener {
      val destIntent = AndroidSmallEighteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyTwo.setOnClickListener {
      val destIntent = AndroidSmallThirtytwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThree.setOnClickListener {
      val destIntent = AndroidSmallThreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallTwentySix.setOnClickListener {
      val destIntent = AndroidSmallTwentysixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyThree.setOnClickListener {
      val destIntent = AndroidSmallThirtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSixtyThree.setOnClickListener {
      val destIntent = AndroidSmallSixtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyEight.setOnClickListener {
      val destIntent = AndroidSmallThirtyeightActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSeventyTwo.setOnClickListener {
      val destIntent = AndroidSmallSeventytwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSixtySix.setOnClickListener {
      val destIntent = AndroidSmallSixtysixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSeven.setOnClickListener {
      val destIntent = AndroidSmallSevenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtySix.setOnClickListener {
      val destIntent = AndroidSmallThirtysixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSeventy.setOnClickListener {
      val destIntent = AndroidSmallSeventyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallTwentyFour.setOnClickListener {
      val destIntent = AndroidSmallTwentyfourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallFortyOne.setOnClickListener {
      val destIntent = AndroidSmallFortyoneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallForty.setOnClickListener {
      val destIntent = AndroidSmallFortyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallTwo.setOnClickListener {
      val destIntent = AndroidSmallTwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSeventeen.setOnClickListener {
      val destIntent = AndroidSmallSeventeenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallTwentyFive.setOnClickListener {
      val destIntent = AndroidSmallTwentyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallTwentyThree.setOnClickListener {
      val destIntent = AndroidSmallTwentythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSixteen.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyFour.setOnClickListener {
      val destIntent = AndroidSmallThirtyfourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyNine.setOnClickListener {
      val destIntent = AndroidSmallThirtynineActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallOne.setOnClickListener {
      val destIntent = AndroidSmallOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallEight.setOnClickListener {
      val destIntent = AndroidSmallEightActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallNineteen.setOnClickListener {
      val destIntent = AndroidSmallNineteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSixtyEight.setOnClickListener {
      val destIntent = AndroidSmallSixtyeightActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallFour.setOnClickListener {
      val destIntent = AndroidSmallFourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSeventyOne.setOnClickListener {
      val destIntent = AndroidSmallSeventyoneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtySeven.setOnClickListener {
      val destIntent = AndroidSmallThirtysevenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSixtyNine.setOnClickListener {
      val destIntent = AndroidSmallSixtynineActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyFive.setOnClickListener {
      val destIntent = AndroidSmallThirtyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallSix.setOnClickListener {
      val destIntent = AndroidSmallSixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallFive.setOnClickListener {
      val destIntent = AndroidSmallFiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearAndroidSmallThirtyOne.setOnClickListener {
      val destIntent = AndroidSmallThirtyoneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "APP_NAVIGATION_ACTIVITY"

  }
}
