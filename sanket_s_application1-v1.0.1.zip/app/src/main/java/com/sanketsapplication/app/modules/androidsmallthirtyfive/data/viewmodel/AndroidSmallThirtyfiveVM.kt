package com.sanketsapplication.app.modules.androidsmallthirtyfive.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtyfive.`data`.model.AndroidSmallThirtyfiveModel
import org.koin.core.KoinComponent

class AndroidSmallThirtyfiveVM : ViewModel(), KoinComponent {
  val androidSmallThirtyfiveModel: MutableLiveData<AndroidSmallThirtyfiveModel> =
      MutableLiveData(AndroidSmallThirtyfiveModel())

  var navArguments: Bundle? = null
}
