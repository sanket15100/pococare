package com.sanketsapplication.app.modules.androidsmallfour.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallFourModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtWewillbether: String? =
      MyApp.getInstance().resources.getString(R.string.msg_we_will_be_ther)

)
