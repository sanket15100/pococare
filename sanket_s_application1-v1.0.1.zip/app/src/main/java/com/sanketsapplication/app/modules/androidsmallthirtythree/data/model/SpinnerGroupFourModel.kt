package com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.model

import kotlin.String

data class SpinnerGroupFourModel(
  val itemName: String
)
