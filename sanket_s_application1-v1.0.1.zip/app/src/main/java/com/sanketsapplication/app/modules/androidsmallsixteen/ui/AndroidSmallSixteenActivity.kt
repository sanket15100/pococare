package com.sanketsapplication.app.modules.androidsmallsixteen.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSixteenBinding
import com.sanketsapplication.app.modules.androidsmalleighteen.ui.AndroidSmallEighteenActivity
import com.sanketsapplication.app.modules.androidsmallseventeen.ui.AndroidSmallSeventeenActivity
import com.sanketsapplication.app.modules.androidsmallsixteen.`data`.viewmodel.AndroidSmallSixteenVM
import com.sanketsapplication.app.modules.androidsmalltwentyfour.ui.AndroidSmallTwentyfourActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallSixteenActivity :
    BaseActivity<ActivityAndroidSmallSixteenBinding>(R.layout.activity_android_small_sixteen) {
  private val viewModel: AndroidSmallSixteenVM by viewModels<AndroidSmallSixteenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallSixteenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageVectorTwo.setOnClickListener {
      val destIntent = AndroidSmallSeventeenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnuser.setOnClickListener {
      val destIntent = AndroidSmallTwentyfourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearRowvectorTwo.setOnClickListener {
      val destIntent = AndroidSmallEighteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SIXTEEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSixteenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
