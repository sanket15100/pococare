package com.sanketsapplication.app.modules.androidsmalltwentyfour.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallTwentyfourBinding
import com.sanketsapplication.app.modules.androidsmallsix.ui.AndroidSmallSixActivity
import com.sanketsapplication.app.modules.androidsmalltwentyfour.`data`.viewmodel.AndroidSmallTwentyfourVM
import kotlin.String
import kotlin.Unit

class AndroidSmallTwentyfourActivity :
    BaseActivity<ActivityAndroidSmallTwentyfourBinding>(R.layout.activity_android_small_twentyfour)
    {
  private val viewModel: AndroidSmallTwentyfourVM by viewModels<AndroidSmallTwentyfourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallTwentyfourVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnLogout.setOnClickListener {
      val destIntent = AndroidSmallSixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_TWENTYFOUR_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallTwentyfourActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
