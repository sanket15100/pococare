package com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.model.AndroidSmallThirtysixModel
import com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.model.SpinnerGroupThreeModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class AndroidSmallThirtysixVM : ViewModel(), KoinComponent {
  val androidSmallThirtysixModel: MutableLiveData<AndroidSmallThirtysixModel> =
      MutableLiveData(AndroidSmallThirtysixModel())

  var navArguments: Bundle? = null

  val spinnerGroupThreeList: MutableLiveData<MutableList<SpinnerGroupThreeModel>> =
      MutableLiveData()
}
