package com.sanketsapplication.app.modules.androidsmallseven.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallSevenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPoco: String? = MyApp.getInstance().resources.getString(R.string.lbl_poco)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAnOTPhasbein: String? =
      MyApp.getInstance().resources.getString(R.string.msg_an_otp_has_bein)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDuration: String? = MyApp.getInstance().resources.getString(R.string.msg_resend_otp_in_3)

)
