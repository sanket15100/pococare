package com.sanketsapplication.app.modules.androidsmallthree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthree.`data`.model.AndroidSmallThreeModel
import org.koin.core.KoinComponent

class AndroidSmallThreeVM : ViewModel(), KoinComponent {
  val androidSmallThreeModel: MutableLiveData<AndroidSmallThreeModel> =
      MutableLiveData(AndroidSmallThreeModel())

  var navArguments: Bundle? = null
}
