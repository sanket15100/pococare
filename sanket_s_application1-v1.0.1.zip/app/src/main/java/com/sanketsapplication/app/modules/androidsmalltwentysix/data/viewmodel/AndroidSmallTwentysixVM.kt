package com.sanketsapplication.app.modules.androidsmalltwentysix.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmalltwentysix.`data`.model.AndroidSmallTwentysixModel
import org.koin.core.KoinComponent

class AndroidSmallTwentysixVM : ViewModel(), KoinComponent {
  val androidSmallTwentysixModel: MutableLiveData<AndroidSmallTwentysixModel> =
      MutableLiveData(AndroidSmallTwentysixModel())

  var navArguments: Bundle? = null
}
