package com.sanketsapplication.app.modules.androidsmalltwo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallTwoBinding
import com.sanketsapplication.app.modules.androidsmalltwo.`data`.viewmodel.AndroidSmallTwoVM
import kotlin.String
import kotlin.Unit

class AndroidSmallTwoActivity :
    BaseActivity<ActivityAndroidSmallTwoBinding>(R.layout.activity_android_small_two) {
  private val viewModel: AndroidSmallTwoVM by viewModels<AndroidSmallTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_TWO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallTwoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
