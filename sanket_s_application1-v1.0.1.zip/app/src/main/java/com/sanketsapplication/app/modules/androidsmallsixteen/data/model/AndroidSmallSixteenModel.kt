package com.sanketsapplication.app.modules.androidsmallsixteen.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallSixteenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPoco: String? = MyApp.getInstance().resources.getString(R.string.lbl_poco)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEnjoyyourPeac: String? =
      MyApp.getInstance().resources.getString(R.string.msg_enjoy_your_peac)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPOCOMAGICisin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_pocomagic_is_in)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMyBeneficiary: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_my_beneficiary)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMeenakshi: String? = MyApp.getInstance().resources.getString(R.string.lbl_meenakshi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMother: String? = MyApp.getInstance().resources.getString(R.string.lbl_mother)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddBeneficiary: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_add_beneficiary)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)

)
