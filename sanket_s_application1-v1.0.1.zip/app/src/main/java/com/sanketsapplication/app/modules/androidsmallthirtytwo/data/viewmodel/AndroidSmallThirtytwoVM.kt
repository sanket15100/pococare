package com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.model.AndroidSmallThirtytwoModel
import com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.model.SpinnerGroupEightModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class AndroidSmallThirtytwoVM : ViewModel(), KoinComponent {
  val androidSmallThirtytwoModel: MutableLiveData<AndroidSmallThirtytwoModel> =
      MutableLiveData(AndroidSmallThirtytwoModel())

  var navArguments: Bundle? = null

  val spinnerGroupEightList: MutableLiveData<MutableList<SpinnerGroupEightModel>> =
      MutableLiveData()
}
