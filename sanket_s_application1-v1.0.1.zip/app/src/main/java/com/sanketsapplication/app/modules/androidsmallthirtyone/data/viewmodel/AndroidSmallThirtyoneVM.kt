package com.sanketsapplication.app.modules.androidsmallthirtyone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtyone.`data`.model.AndroidSmallThirtyoneModel
import org.koin.core.KoinComponent

class AndroidSmallThirtyoneVM : ViewModel(), KoinComponent {
  val androidSmallThirtyoneModel: MutableLiveData<AndroidSmallThirtyoneModel> =
      MutableLiveData(AndroidSmallThirtyoneModel())

  var navArguments: Bundle? = null
}
