package com.sanketsapplication.app.modules.androidsmallthirtyeight.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtyeightModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtShareoverWhat: String? =
      MyApp.getInstance().resources.getString(R.string.msg_share_over_what)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSaveasPDF: String? = MyApp.getInstance().resources.getString(R.string.lbl_save_as_pdf)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSaveasimage: String? = MyApp.getInstance().resources.getString(R.string.lbl_save_as_image)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrint: String? = MyApp.getInstance().resources.getString(R.string.lbl_print)

)
