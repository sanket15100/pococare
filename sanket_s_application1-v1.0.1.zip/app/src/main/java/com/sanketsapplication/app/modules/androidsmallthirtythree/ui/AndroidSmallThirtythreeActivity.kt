package com.sanketsapplication.app.modules.androidsmallthirtythree.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtythreeBinding
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtyfour.ui.AndroidSmallThirtyfourActivity
import com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.model.SpinnerGroupFourModel
import com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.viewmodel.AndroidSmallThirtythreeVM
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtythreeActivity :
    BaseActivity<ActivityAndroidSmallThirtythreeBinding>(R.layout.activity_android_small_thirtythree)
    {
  private val viewModel: AndroidSmallThirtythreeVM by viewModels<AndroidSmallThirtythreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupFourList.value = mutableListOf(
    SpinnerGroupFourModel("Item1"),
    SpinnerGroupFourModel("Item2"),
    SpinnerGroupFourModel("Item3"),
    SpinnerGroupFourModel("Item4"),
    SpinnerGroupFourModel("Item5")
    )
    val spinnerGroupFourAdapter =
    SpinnerGroupFourAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupFourList.value?:
    mutableListOf())
    binding.spinnerGroupFour.adapter = spinnerGroupFourAdapter
    binding.androidSmallThirtythreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnSave.setOnClickListener {
      val destIntent = AndroidSmallThirtyfourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYTHREE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtythreeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
