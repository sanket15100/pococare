package com.sanketsapplication.app.modules.androidsmallnineteen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallnineteen.`data`.model.AndroidSmallNineteenModel
import org.koin.core.KoinComponent

class AndroidSmallNineteenVM : ViewModel(), KoinComponent {
  val androidSmallNineteenModel: MutableLiveData<AndroidSmallNineteenModel> =
      MutableLiveData(AndroidSmallNineteenModel())

  var navArguments: Bundle? = null
}
