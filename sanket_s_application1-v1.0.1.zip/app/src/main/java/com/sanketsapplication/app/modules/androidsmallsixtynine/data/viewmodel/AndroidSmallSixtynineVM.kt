package com.sanketsapplication.app.modules.androidsmallsixtynine.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallsixtynine.`data`.model.AndroidSmallSixtynineModel
import org.koin.core.KoinComponent

class AndroidSmallSixtynineVM : ViewModel(), KoinComponent {
  val androidSmallSixtynineModel: MutableLiveData<AndroidSmallSixtynineModel> =
      MutableLiveData(AndroidSmallSixtynineModel())

  var navArguments: Bundle? = null
}
