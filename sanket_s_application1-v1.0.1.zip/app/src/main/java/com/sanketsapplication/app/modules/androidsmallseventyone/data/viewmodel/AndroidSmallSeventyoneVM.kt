package com.sanketsapplication.app.modules.androidsmallseventyone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallseventyone.`data`.model.AndroidSmallSeventyoneModel
import org.koin.core.KoinComponent

class AndroidSmallSeventyoneVM : ViewModel(), KoinComponent {
  val androidSmallSeventyoneModel: MutableLiveData<AndroidSmallSeventyoneModel> =
      MutableLiveData(AndroidSmallSeventyoneModel())

  var navArguments: Bundle? = null
}
