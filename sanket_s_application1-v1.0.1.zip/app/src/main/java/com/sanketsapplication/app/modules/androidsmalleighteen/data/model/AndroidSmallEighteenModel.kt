package com.sanketsapplication.app.modules.androidsmalleighteen.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallEighteenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMeenakshi: String? = MyApp.getInstance().resources.getString(R.string.lbl_meenakshi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGender: String? = MyApp.getInstance().resources.getString(R.string.msg_age_50_yrs)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMother: String? = MyApp.getInstance().resources.getString(R.string.lbl_mother)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddress: String? = MyApp.getInstance().resources.getString(R.string.lbl_address)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtE401Regency: String? = MyApp.getInstance().resources.getString(R.string.msg_e_401_regency)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKadabishanhalliOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_kadabishanhalli)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOne: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBangalore: String? = MyApp.getInstance().resources.getString(R.string.lbl_bangalore2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtZipcode: String? = MyApp.getInstance().resources.getString(R.string.lbl_560103)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOppositeBellan: String? =
      MyApp.getInstance().resources.getString(R.string.msg_opposite_bellan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmergencyConta: String? =
      MyApp.getInstance().resources.getString(R.string.msg_emergency_conta2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDaughter: String? = MyApp.getInstance().resources.getString(R.string.lbl_daughter)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBhavya: String? = MyApp.getInstance().resources.getString(R.string.lbl_bhavya)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt917738335734: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_91_77383_35734)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
