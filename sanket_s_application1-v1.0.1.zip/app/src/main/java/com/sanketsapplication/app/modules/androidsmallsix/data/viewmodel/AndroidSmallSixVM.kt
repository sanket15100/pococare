package com.sanketsapplication.app.modules.androidsmallsix.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallsix.`data`.model.AndroidSmallSixModel
import com.sanketsapplication.app.modules.androidsmallsix.`data`.model.SpinnerGroupSixtyFiveModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class AndroidSmallSixVM : ViewModel(), KoinComponent {
  val androidSmallSixModel: MutableLiveData<AndroidSmallSixModel> =
      MutableLiveData(AndroidSmallSixModel())

  var navArguments: Bundle? = null

  val spinnerGroupSixtyFiveList: MutableLiveData<MutableList<SpinnerGroupSixtyFiveModel>> =
      MutableLiveData()
}
