package com.sanketsapplication.app.modules.androidsmallthirtysix.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtysixBinding
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.model.SpinnerGroupThreeModel
import com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.viewmodel.AndroidSmallThirtysixVM
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtysixActivity :
    BaseActivity<ActivityAndroidSmallThirtysixBinding>(R.layout.activity_android_small_thirtysix) {
  private val viewModel: AndroidSmallThirtysixVM by viewModels<AndroidSmallThirtysixVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupThreeList.value = mutableListOf(
    SpinnerGroupThreeModel("Item1"),
    SpinnerGroupThreeModel("Item2"),
    SpinnerGroupThreeModel("Item3"),
    SpinnerGroupThreeModel("Item4"),
    SpinnerGroupThreeModel("Item5")
    )
    val spinnerGroupThreeAdapter =
    SpinnerGroupThreeAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupThreeList.value?:
    mutableListOf())
    binding.spinnerGroupThree.adapter = spinnerGroupThreeAdapter
    binding.androidSmallThirtysixVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnVerify.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYSIX_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtysixActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
