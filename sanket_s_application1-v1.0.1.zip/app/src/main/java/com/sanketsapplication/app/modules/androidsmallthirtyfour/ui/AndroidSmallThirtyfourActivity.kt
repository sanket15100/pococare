package com.sanketsapplication.app.modules.androidsmallthirtyfour.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtyfourBinding
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtyfive.ui.AndroidSmallThirtyfiveActivity
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.ListrecenthospitalRowModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.SpinnerGroupEighteenModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.SpinnerGroupFortySevenModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.SpinnerGroupThreeModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.viewmodel.AndroidSmallThirtyfourVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtyfourActivity :
    BaseActivity<ActivityAndroidSmallThirtyfourBinding>(R.layout.activity_android_small_thirtyfour)
    {
  private val viewModel: AndroidSmallThirtyfourVM by viewModels<AndroidSmallThirtyfourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupThreeList.value = mutableListOf(
    SpinnerGroupThreeModel("Item1"),
    SpinnerGroupThreeModel("Item2"),
    SpinnerGroupThreeModel("Item3"),
    SpinnerGroupThreeModel("Item4"),
    SpinnerGroupThreeModel("Item5")
    )
    val spinnerGroupThreeAdapter =
    SpinnerGroupThreeAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupThreeList.value?:
    mutableListOf())
    binding.spinnerGroupThree.adapter = spinnerGroupThreeAdapter
    viewModel.spinnerGroupEighteenList.value = mutableListOf(
    SpinnerGroupEighteenModel("Item1"),
    SpinnerGroupEighteenModel("Item2"),
    SpinnerGroupEighteenModel("Item3"),
    SpinnerGroupEighteenModel("Item4"),
    SpinnerGroupEighteenModel("Item5")
    )
    val spinnerGroupEighteenAdapter =
    SpinnerGroupEighteenAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupEighteenList.value?:
    mutableListOf())
    binding.spinnerGroupEighteen.adapter = spinnerGroupEighteenAdapter
    viewModel.spinnerGroupFortySevenList.value = mutableListOf(
    SpinnerGroupFortySevenModel("Item1"),
    SpinnerGroupFortySevenModel("Item2"),
    SpinnerGroupFortySevenModel("Item3"),
    SpinnerGroupFortySevenModel("Item4"),
    SpinnerGroupFortySevenModel("Item5")
    )
    val spinnerGroupFortySevenAdapter =
    SpinnerGroupFortySevenAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupFortySevenList.value?:
    mutableListOf())
    binding.spinnerGroupFortySeven.adapter = spinnerGroupFortySevenAdapter
    val listrecenthospitalAdapter =
    ListrecenthospitalAdapter(viewModel.listrecenthospitalList.value?:mutableListOf())
    binding.recyclerListrecenthospital.adapter = listrecenthospitalAdapter
    listrecenthospitalAdapter.setOnItemClickListener(
    object : ListrecenthospitalAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListrecenthospitalRowModel) {
        onClickRecyclerListrecenthospital(view, position, item)
      }
    }
    )
    viewModel.listrecenthospitalList.observe(this) {
      listrecenthospitalAdapter.updateData(it)
    }
    binding.androidSmallThirtyfourVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnSave.setOnClickListener {
      val destIntent = AndroidSmallThirtyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerListrecenthospital(
    view: View,
    position: Int,
    item: ListrecenthospitalRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYFOUR_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtyfourActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
