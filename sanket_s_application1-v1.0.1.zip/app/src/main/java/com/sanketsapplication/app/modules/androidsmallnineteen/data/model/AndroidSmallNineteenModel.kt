package com.sanketsapplication.app.modules.androidsmallnineteen.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallNineteenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMeenakshi: String? = MyApp.getInstance().resources.getString(R.string.lbl_meenakshi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGender: String? = MyApp.getInstance().resources.getString(R.string.msg_age_50_yrs)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtO: String? = MyApp.getInstance().resources.getString(R.string.lbl_o)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNo: String? = MyApp.getInstance().resources.getString(R.string.lbl_no)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtChronicconditi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_chronic_conditi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedications: String? = MyApp.getInstance().resources.getString(R.string.lbl_medications)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroupNineteen: String? = MyApp.getInstance().resources.getString(R.string.lbl_no)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAllergiesRea: String? = MyApp.getInstance().resources.getString(R.string.msg_allergies_rea)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroupTwenty: String? = MyApp.getInstance().resources.getString(R.string.lbl_no)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalNotes: String? = MyApp.getInstance().resources.getString(R.string.lbl_medical_notes)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfileOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupEighteenValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwentyOneValue: String? = null
)
