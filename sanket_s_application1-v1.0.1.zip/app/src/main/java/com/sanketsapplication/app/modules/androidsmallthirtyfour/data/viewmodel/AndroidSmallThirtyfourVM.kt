package com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.AndroidSmallThirtyfourModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.ListrecenthospitalRowModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.SpinnerGroupEighteenModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.SpinnerGroupFortySevenModel
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.SpinnerGroupThreeModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class AndroidSmallThirtyfourVM : ViewModel(), KoinComponent {
  val androidSmallThirtyfourModel: MutableLiveData<AndroidSmallThirtyfourModel> =
      MutableLiveData(AndroidSmallThirtyfourModel())

  var navArguments: Bundle? = null

  val spinnerGroupThreeList: MutableLiveData<MutableList<SpinnerGroupThreeModel>> =
      MutableLiveData()

  val spinnerGroupEighteenList: MutableLiveData<MutableList<SpinnerGroupEighteenModel>> =
      MutableLiveData()

  val spinnerGroupFortySevenList: MutableLiveData<MutableList<SpinnerGroupFortySevenModel>> =
      MutableLiveData()

  val listrecenthospitalList: MutableLiveData<MutableList<ListrecenthospitalRowModel>> =
      MutableLiveData(mutableListOf())
}
