package com.sanketsapplication.app.modules.androidsmallthirtyfive.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtyfiveBinding
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtyfive.`data`.viewmodel.AndroidSmallThirtyfiveVM
import com.sanketsapplication.app.modules.androidsmallthirtysix.ui.AndroidSmallThirtysixActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtyfiveActivity :
    BaseActivity<ActivityAndroidSmallThirtyfiveBinding>(R.layout.activity_android_small_thirtyfive)
    {
  private val viewModel: AndroidSmallThirtyfiveVM by viewModels<AndroidSmallThirtyfiveVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallThirtyfiveVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSave.setOnClickListener {
      val destIntent = AndroidSmallThirtysixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYFIVE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtyfiveActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
