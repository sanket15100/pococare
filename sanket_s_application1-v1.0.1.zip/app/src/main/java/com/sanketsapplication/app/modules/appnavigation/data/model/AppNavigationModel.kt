package com.sanketsapplication.app.modules.appnavigation.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AppNavigationModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAppNavigation: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_app_navigation)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCheckYourAppsUIFromTheBelowDemoScreensOfYourApp: String? =
      MyApp.getInstance().resources.getString(R.string.msg_check_your_app)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallFour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallFive: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSeven: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small6)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallEight: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small7)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small8)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small9)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small10)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyFour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small11)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyFive: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small12)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtySix: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small13)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSixteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small14)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSeventeen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small15)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallEighteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small16)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallNineteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small17)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSixtyThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small18)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSixtyEight: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small19)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallTwentyFive: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small20)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallTwentySix: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small21)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallTwentyThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small22)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyNine: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small23)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallTwentyFour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small24)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSix: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small25)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSixtyNine: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small26)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallForty: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small27)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtySeven: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small28)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallThirtyEight: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small29)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallFortyOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small30)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSeventyTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small31)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSeventy: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small32)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSixtySix: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small33)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAndroidSmallSeventyOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_android_small34)

)
