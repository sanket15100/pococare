package com.sanketsapplication.app.modules.androidsmallthirtyfour.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.sanketsapplication.app.R
import com.sanketsapplication.app.databinding.RowListrecenthospitalBinding
import com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model.ListrecenthospitalRowModel
import kotlin.Int
import kotlin.collections.List

class ListrecenthospitalAdapter(
  var list: List<ListrecenthospitalRowModel>
) : RecyclerView.Adapter<ListrecenthospitalAdapter.RowListrecenthospitalVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListrecenthospitalVH {
    val
        view=LayoutInflater.from(parent.context).inflate(R.layout.row_listrecenthospital,parent,false)
    return RowListrecenthospitalVH(view)
  }

  override fun onBindViewHolder(holder: RowListrecenthospitalVH, position: Int) {
    val listrecenthospitalRowModel = ListrecenthospitalRowModel()
    // TODO uncomment following line after integration with data source
    // val listrecenthospitalRowModel = list[position]
    holder.binding.listrecenthospitalRowModel = listrecenthospitalRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListrecenthospitalRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListrecenthospitalRowModel
    ) {
    }
  }

  inner class RowListrecenthospitalVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListrecenthospitalBinding = RowListrecenthospitalBinding.bind(itemView)
  }
}
