package com.sanketsapplication.app.modules.androidsmallthree.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThreeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtSkip: String? = MyApp.getInstance().resources.getString(R.string.lbl_skip)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIncaseofmedi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_in_case_of_medi)

)
