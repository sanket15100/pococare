package com.sanketsapplication.app.modules.androidsmallsixtyeight.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallSixtyeightModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtListofnearby: String? =
      MyApp.getInstance().resources.getString(R.string.msg_list_of_nearby)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCurrentlocatio: String? =
      MyApp.getInstance().resources.getString(R.string.msg_current_locatio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDistance: String? = MyApp.getInstance().resources.getString(R.string.msg_nearest_hospita)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMap: String? = MyApp.getInstance().resources.getString(R.string.lbl_map)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_new_life_hospit2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDuration: String? = MyApp.getInstance().resources.getString(R.string.msg_3_4_km_15_minu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtJeevikaHospita: String? =
      MyApp.getInstance().resources.getString(R.string.msg_jeevika_hospita)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationOne: String? = MyApp.getInstance().resources.getString(R.string.msg_4_2_km_19_minu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtVaidehiHospita: String? =
      MyApp.getInstance().resources.getString(R.string.msg_vaidehi_hospita)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationTwo: String? = MyApp.getInstance().resources.getString(R.string.msg_5_5_km_22_minu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtManipalHospita: String? =
      MyApp.getInstance().resources.getString(R.string.msg_manipal_hospita)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_5_7_km_24_minu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSAKRAHospital: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sakra_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationFour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_6_4_km_24_minu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtClickthehospi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_click_the_hospi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
