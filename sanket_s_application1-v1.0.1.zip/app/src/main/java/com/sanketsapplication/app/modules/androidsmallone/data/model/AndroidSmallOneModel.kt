package com.sanketsapplication.app.modules.androidsmallone.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPoco: String? = MyApp.getInstance().resources.getString(R.string.lbl_poco)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMakingelderse: String? =
      MyApp.getInstance().resources.getString(R.string.msg_making_elders_e)

)
