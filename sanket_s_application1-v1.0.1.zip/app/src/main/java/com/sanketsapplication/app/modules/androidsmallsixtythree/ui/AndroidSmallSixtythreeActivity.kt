package com.sanketsapplication.app.modules.androidsmallsixtythree.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSixtythreeBinding
import com.sanketsapplication.app.modules.androidsmallnineteen.ui.AndroidSmallNineteenActivity
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallsixtyeight.ui.AndroidSmallSixtyeightActivity
import com.sanketsapplication.app.modules.androidsmallsixtythree.`data`.viewmodel.AndroidSmallSixtythreeVM
import com.sanketsapplication.app.modules.androidsmalltwentyfive.ui.AndroidSmallTwentyfiveActivity
import com.sanketsapplication.app.modules.androidsmalltwentythree.ui.AndroidSmallTwentythreeActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallSixtythreeActivity :
    BaseActivity<ActivityAndroidSmallSixtythreeBinding>(R.layout.activity_android_small_sixtythree)
    {
  private val viewModel: AndroidSmallSixtythreeVM by viewModels<AndroidSmallSixtythreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallSixtythreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearRowlist.setOnClickListener {
      val destIntent = AndroidSmallSixtyeightActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumntrophy.setOnClickListener {
      val destIntent = AndroidSmallTwentythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumndownload.setOnClickListener {
      val destIntent = AndroidSmallTwentyfiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearColumnedit.setOnClickListener {
      val destIntent = AndroidSmallNineteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SIXTYTHREE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSixtythreeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
