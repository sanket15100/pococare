package com.sanketsapplication.app.modules.androidsmallsixtysix.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallSixtysixModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_reaching_pick_u)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_6_min)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKA01BA5498: String? = MyApp.getInstance().resources.getString(R.string.lbl_ka_01_ba_5498)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTataAdvancedL: String? =
      MyApp.getInstance().resources.getString(R.string.msg_tata_advanced_l)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMahesh: String? = MyApp.getInstance().resources.getString(R.string.lbl_mahesh)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
