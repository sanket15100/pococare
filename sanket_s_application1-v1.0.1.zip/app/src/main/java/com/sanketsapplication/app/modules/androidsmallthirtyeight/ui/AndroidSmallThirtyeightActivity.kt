package com.sanketsapplication.app.modules.androidsmallthirtyeight.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtyeightBinding
import com.sanketsapplication.app.modules.androidsmalleighteen.ui.AndroidSmallEighteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtyeight.`data`.viewmodel.AndroidSmallThirtyeightVM
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtyeightActivity :
    BaseActivity<ActivityAndroidSmallThirtyeightBinding>(R.layout.activity_android_small_thirtyeight)
    {
  private val viewModel: AndroidSmallThirtyeightVM by viewModels<AndroidSmallThirtyeightVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallThirtyeightVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallEighteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYEIGHT_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtyeightActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
