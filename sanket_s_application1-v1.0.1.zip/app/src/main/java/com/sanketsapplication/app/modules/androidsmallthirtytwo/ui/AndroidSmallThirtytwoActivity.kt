package com.sanketsapplication.app.modules.androidsmallthirtytwo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtytwoBinding
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtythree.ui.AndroidSmallThirtythreeActivity
import com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.model.SpinnerGroupEightModel
import com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.viewmodel.AndroidSmallThirtytwoVM
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtytwoActivity :
    BaseActivity<ActivityAndroidSmallThirtytwoBinding>(R.layout.activity_android_small_thirtytwo) {
  private val viewModel: AndroidSmallThirtytwoVM by viewModels<AndroidSmallThirtytwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupEightList.value = mutableListOf(
    SpinnerGroupEightModel("Item1"),
    SpinnerGroupEightModel("Item2"),
    SpinnerGroupEightModel("Item3"),
    SpinnerGroupEightModel("Item4"),
    SpinnerGroupEightModel("Item5")
    )
    val spinnerGroupEightAdapter =
    SpinnerGroupEightAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupEightList.value?:
    mutableListOf())
    binding.spinnerGroupEight.adapter = spinnerGroupEightAdapter
    binding.androidSmallThirtytwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSave.setOnClickListener {
      val destIntent = AndroidSmallThirtythreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYTWO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtytwoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
