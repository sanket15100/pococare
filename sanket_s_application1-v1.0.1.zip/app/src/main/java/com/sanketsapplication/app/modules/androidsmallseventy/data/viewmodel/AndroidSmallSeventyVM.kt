package com.sanketsapplication.app.modules.androidsmallseventy.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallseventy.`data`.model.AndroidSmallSeventyModel
import org.koin.core.KoinComponent

class AndroidSmallSeventyVM : ViewModel(), KoinComponent {
  val androidSmallSeventyModel: MutableLiveData<AndroidSmallSeventyModel> =
      MutableLiveData(AndroidSmallSeventyModel())

  var navArguments: Bundle? = null
}
