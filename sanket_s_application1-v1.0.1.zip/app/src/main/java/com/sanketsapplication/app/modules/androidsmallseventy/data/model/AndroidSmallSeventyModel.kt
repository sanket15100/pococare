package com.sanketsapplication.app.modules.androidsmallseventy.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallSeventyModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctorconsulta: String? =
      MyApp.getInstance().resources.getString(R.string.msg_doctor_consulta)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDrMamtha: String? = MyApp.getInstance().resources.getString(R.string.lbl_dr_mamtha)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalnotes: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_notes2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtConsultationin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_consultation_in)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_00_13)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
