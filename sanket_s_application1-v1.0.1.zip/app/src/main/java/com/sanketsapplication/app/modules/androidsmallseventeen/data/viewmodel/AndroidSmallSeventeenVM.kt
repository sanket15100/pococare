package com.sanketsapplication.app.modules.androidsmallseventeen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallseventeen.`data`.model.AndroidSmallSeventeenModel
import org.koin.core.KoinComponent

class AndroidSmallSeventeenVM : ViewModel(), KoinComponent {
  val androidSmallSeventeenModel: MutableLiveData<AndroidSmallSeventeenModel> =
      MutableLiveData(AndroidSmallSeventeenModel())

  var navArguments: Bundle? = null
}
