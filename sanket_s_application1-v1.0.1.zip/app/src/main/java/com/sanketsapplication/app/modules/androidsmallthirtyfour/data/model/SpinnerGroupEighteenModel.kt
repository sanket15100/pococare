package com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model

import kotlin.String

data class SpinnerGroupEighteenModel(
  val itemName: String
)
