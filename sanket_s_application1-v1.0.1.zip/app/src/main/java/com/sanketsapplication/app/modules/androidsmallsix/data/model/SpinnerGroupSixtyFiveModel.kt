package com.sanketsapplication.app.modules.androidsmallsix.`data`.model

import kotlin.String

data class SpinnerGroupSixtyFiveModel(
  val itemName: String
)
