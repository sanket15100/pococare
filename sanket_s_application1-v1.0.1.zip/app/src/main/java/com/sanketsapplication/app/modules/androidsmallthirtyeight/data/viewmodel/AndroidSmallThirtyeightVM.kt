package com.sanketsapplication.app.modules.androidsmallthirtyeight.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallthirtyeight.`data`.model.AndroidSmallThirtyeightModel
import org.koin.core.KoinComponent

class AndroidSmallThirtyeightVM : ViewModel(), KoinComponent {
  val androidSmallThirtyeightModel: MutableLiveData<AndroidSmallThirtyeightModel> =
      MutableLiveData(AndroidSmallThirtyeightModel())

  var navArguments: Bundle? = null
}
