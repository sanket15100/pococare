package com.sanketsapplication.app.modules.androidsmallone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallOneBinding
import com.sanketsapplication.app.modules.androidsmallone.`data`.viewmodel.AndroidSmallOneVM
import com.sanketsapplication.app.modules.androidsmalltwo.ui.AndroidSmallTwoActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallOneActivity :
    BaseActivity<ActivityAndroidSmallOneBinding>(R.layout.activity_android_small_one) {
  private val viewModel: AndroidSmallOneVM by viewModels<AndroidSmallOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallOneVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = AndroidSmallTwoActivity.getIntent(this, null)
      startActivity(destIntent)
      }, 3000)
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "ANDROID_SMALL_ONE_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, AndroidSmallOneActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
