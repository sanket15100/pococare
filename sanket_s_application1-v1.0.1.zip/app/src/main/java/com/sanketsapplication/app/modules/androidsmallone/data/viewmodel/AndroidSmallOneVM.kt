package com.sanketsapplication.app.modules.androidsmallone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallone.`data`.model.AndroidSmallOneModel
import org.koin.core.KoinComponent

class AndroidSmallOneVM : ViewModel(), KoinComponent {
  val androidSmallOneModel: MutableLiveData<AndroidSmallOneModel> =
      MutableLiveData(AndroidSmallOneModel())

  var navArguments: Bundle? = null
}
