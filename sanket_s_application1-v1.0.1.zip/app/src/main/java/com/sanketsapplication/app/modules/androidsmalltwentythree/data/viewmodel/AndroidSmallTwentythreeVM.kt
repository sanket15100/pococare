package com.sanketsapplication.app.modules.androidsmalltwentythree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmalltwentythree.`data`.model.AndroidSmallTwentythreeModel
import org.koin.core.KoinComponent

class AndroidSmallTwentythreeVM : ViewModel(), KoinComponent {
  val androidSmallTwentythreeModel: MutableLiveData<AndroidSmallTwentythreeModel> =
      MutableLiveData(AndroidSmallTwentythreeModel())

  var navArguments: Bundle? = null
}
