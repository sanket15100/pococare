package com.sanketsapplication.app.modules.androidsmallseventeen.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSeventeenBinding
import com.sanketsapplication.app.modules.androidsmallseventeen.`data`.viewmodel.AndroidSmallSeventeenVM
import com.sanketsapplication.app.modules.androidsmalltwentyfour.ui.AndroidSmallTwentyfourActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallSeventeenActivity :
    BaseActivity<ActivityAndroidSmallSeventeenBinding>(R.layout.activity_android_small_seventeen) {
  private val viewModel: AndroidSmallSeventeenVM by viewModels<AndroidSmallSeventeenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallSeventeenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearColumnuser.setOnClickListener {
      val destIntent = AndroidSmallTwentyfourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SEVENTEEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSeventeenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
