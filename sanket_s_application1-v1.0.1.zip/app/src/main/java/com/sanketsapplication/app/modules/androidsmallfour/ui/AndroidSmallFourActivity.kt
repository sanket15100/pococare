package com.sanketsapplication.app.modules.androidsmallfour.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallFourBinding
import com.sanketsapplication.app.modules.androidsmallfive.ui.AndroidSmallFiveActivity
import com.sanketsapplication.app.modules.androidsmallfour.`data`.viewmodel.AndroidSmallFourVM
import kotlin.String
import kotlin.Unit

class AndroidSmallFourActivity :
    BaseActivity<ActivityAndroidSmallFourBinding>(R.layout.activity_android_small_four) {
  private val viewModel: AndroidSmallFourVM by viewModels<AndroidSmallFourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallFourVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnContinue.setOnClickListener {
      val destIntent = AndroidSmallFiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_FOUR_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallFourActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
