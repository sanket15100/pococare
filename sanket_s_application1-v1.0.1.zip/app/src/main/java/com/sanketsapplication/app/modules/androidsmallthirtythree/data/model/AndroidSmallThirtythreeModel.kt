package com.sanketsapplication.app.modules.androidsmallthirtythree.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtythreeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddemergencyc: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_emergency_c)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_we_will_reach_o)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddupto3emer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_upto_3_emer)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhatsAppnumber: String? =
      MyApp.getInstance().resources.getString(R.string.msg_whatsapp_number)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAssignasprima: String? =
      MyApp.getInstance().resources.getString(R.string.msg_assign_as_prima)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddanothereme: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_another_eme)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupThreeValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etMobileNoValue: String? = null
)
