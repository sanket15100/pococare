package com.sanketsapplication.app.modules.androidsmallsixtynine.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallSixtynineModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtClickonreques: String? =
      MyApp.getInstance().resources.getString(R.string.msg_click_on_reques)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtQualitychecked: String? =
      MyApp.getInstance().resources.getString(R.string.msg_quality_checked)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNewLifeHospit: String? =
      MyApp.getInstance().resources.getString(R.string.msg_new_life_hospit5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBellandur: String? = MyApp.getInstance().resources.getString(R.string.lbl_bellandur)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDuration: String? = MyApp.getInstance().resources.getString(R.string.msg_15_minutes_3_4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSpeciality: String? = MyApp.getInstance().resources.getString(R.string.lbl_speciality)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmergency: String? = MyApp.getInstance().resources.getString(R.string.lbl_emergency)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCardiology: String? = MyApp.getInstance().resources.getString(R.string.lbl_cardiology)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOrthopaedic: String? = MyApp.getInstance().resources.getString(R.string.lbl_orthopaedic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurancecover: String? =
      MyApp.getInstance().resources.getString(R.string.msg_insurance_cover2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_coverage_amount2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRs300000: String? = MyApp.getInstance().resources.getString(R.string.lbl_rs_3_00_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_coverage_amount3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRs250000: String? = MyApp.getInstance().resources.getString(R.string.lbl_rs_2_50_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
