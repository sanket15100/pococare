package com.sanketsapplication.app.modules.androidsmallsix.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallSixBinding
import com.sanketsapplication.app.modules.androidsmalleight.ui.AndroidSmallEightActivity
import com.sanketsapplication.app.modules.androidsmallfive.ui.AndroidSmallFiveActivity
import com.sanketsapplication.app.modules.androidsmallsix.`data`.model.SpinnerGroupSixtyFiveModel
import com.sanketsapplication.app.modules.androidsmallsix.`data`.viewmodel.AndroidSmallSixVM
import kotlin.String
import kotlin.Unit

class AndroidSmallSixActivity :
    BaseActivity<ActivityAndroidSmallSixBinding>(R.layout.activity_android_small_six) {
  private val viewModel: AndroidSmallSixVM by viewModels<AndroidSmallSixVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupSixtyFiveList.value = mutableListOf(
    SpinnerGroupSixtyFiveModel("Item1"),
    SpinnerGroupSixtyFiveModel("Item2"),
    SpinnerGroupSixtyFiveModel("Item3"),
    SpinnerGroupSixtyFiveModel("Item4"),
    SpinnerGroupSixtyFiveModel("Item5")
    )
    val spinnerGroupSixtyFiveAdapter =
    SpinnerGroupSixtyFiveAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupSixtyFiveList.value?:
    mutableListOf())
    binding.spinnerGroupSixtyFive.adapter = spinnerGroupSixtyFiveAdapter
    binding.androidSmallSixVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtRegisterNow.setOnClickListener {
      val destIntent = AndroidSmallFiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnLogin.setOnClickListener {
      val destIntent = AndroidSmallEightActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_SIX_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallSixActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
