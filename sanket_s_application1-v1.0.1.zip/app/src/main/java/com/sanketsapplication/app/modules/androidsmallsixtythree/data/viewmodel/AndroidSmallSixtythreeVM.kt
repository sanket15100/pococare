package com.sanketsapplication.app.modules.androidsmallsixtythree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.sanketsapplication.app.modules.androidsmallsixtythree.`data`.model.AndroidSmallSixtythreeModel
import org.koin.core.KoinComponent

class AndroidSmallSixtythreeVM : ViewModel(), KoinComponent {
  val androidSmallSixtythreeModel: MutableLiveData<AndroidSmallSixtythreeModel> =
      MutableLiveData(AndroidSmallSixtythreeModel())

  var navArguments: Bundle? = null
}
