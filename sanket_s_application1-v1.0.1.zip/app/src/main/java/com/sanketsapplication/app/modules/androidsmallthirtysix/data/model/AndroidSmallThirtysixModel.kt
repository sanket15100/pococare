package com.sanketsapplication.app.modules.androidsmallthirtysix.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtysixModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddInsurancep: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_insurance_p)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_do_not_be_worri)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupFifteenValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etMobileNoValue: String? = null
)
