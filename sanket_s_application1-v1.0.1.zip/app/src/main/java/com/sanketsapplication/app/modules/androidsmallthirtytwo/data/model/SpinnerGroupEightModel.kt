package com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.model

import kotlin.String

data class SpinnerGroupEightModel(
  val itemName: String
)
