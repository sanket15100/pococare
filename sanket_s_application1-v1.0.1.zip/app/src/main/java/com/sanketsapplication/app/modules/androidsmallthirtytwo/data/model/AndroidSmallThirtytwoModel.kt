package com.sanketsapplication.app.modules.androidsmallthirtytwo.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtytwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddaddress: String? = MyApp.getInstance().resources.getString(R.string.lbl_add_address)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_provide_us_the)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddressLineOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_address_line_1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddressLineTwo: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_address_line_2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLandmark: String? = MyApp.getInstance().resources.getString(R.string.lbl_landmark)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTownCity: String? = MyApp.getInstance().resources.getString(R.string.lbl_town_city)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPinCode: String? = MyApp.getInstance().resources.getString(R.string.lbl_pin_code)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtState: String? = MyApp.getInstance().resources.getString(R.string.lbl_state)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupThreeValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupFourValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupFiveValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etLanguageValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etZipcodeValue: String? = null
)
