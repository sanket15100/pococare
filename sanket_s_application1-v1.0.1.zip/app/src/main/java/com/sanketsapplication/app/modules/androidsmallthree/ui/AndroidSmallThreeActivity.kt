package com.sanketsapplication.app.modules.androidsmallthree.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThreeBinding
import com.sanketsapplication.app.modules.androidsmallthree.`data`.viewmodel.AndroidSmallThreeVM
import kotlin.String
import kotlin.Unit

class AndroidSmallThreeActivity :
    BaseActivity<ActivityAndroidSmallThreeBinding>(R.layout.activity_android_small_three) {
  private val viewModel: AndroidSmallThreeVM by viewModels<AndroidSmallThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallThreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THREE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThreeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
