package com.sanketsapplication.app.modules.androidsmallthirtyfour.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtyfourModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddMedicalpro: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_medical_pro)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAccurateandup: String? =
      MyApp.getInstance().resources.getString(R.string.msg_accurate_and_up)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtChronicconditi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_chronic_conditi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtActivemedicati: String? =
      MyApp.getInstance().resources.getString(R.string.msg_active_medicati)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAllergytomedi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_allergy_to_medi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPastmedicalsu: String? =
      MyApp.getInstance().resources.getString(R.string.msg_past_medical_su)

)
