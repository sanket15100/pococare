package com.sanketsapplication.app.modules.androidsmallthirtyone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallThirtyoneBinding
import com.sanketsapplication.app.modules.androidsmallsixteen.ui.AndroidSmallSixteenActivity
import com.sanketsapplication.app.modules.androidsmallthirtyone.`data`.viewmodel.AndroidSmallThirtyoneVM
import com.sanketsapplication.app.modules.androidsmallthirtytwo.ui.AndroidSmallThirtytwoActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallThirtyoneActivity :
    BaseActivity<ActivityAndroidSmallThirtyoneBinding>(R.layout.activity_android_small_thirtyone) {
  private val viewModel: AndroidSmallThirtyoneVM by viewModels<AndroidSmallThirtyoneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.androidSmallThirtyoneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSave.setOnClickListener {
      val destIntent = AndroidSmallThirtytwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AndroidSmallSixteenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_THIRTYONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallThirtyoneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
