package com.sanketsapplication.app.modules.androidsmallthirtyone.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallThirtyoneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddbeneficiary: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_add_beneficiary2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddyourbenefi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_your_benefi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGender: String? = MyApp.getInstance().resources.getString(R.string.lbl_female)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGenderOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_male)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOther: String? = MyApp.getInstance().resources.getString(R.string.lbl_other)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDateofbirth: String? = MyApp.getInstance().resources.getString(R.string.lbl_date_of_birth)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhatsAppnumber: String? =
      MyApp.getInstance().resources.getString(R.string.msg_whatsapp_number)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmploymentStat: String? =
      MyApp.getInstance().resources.getString(R.string.msg_employment_stat)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupThreeValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupFourValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etDateValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etMobileNoValue: String? = null
)
