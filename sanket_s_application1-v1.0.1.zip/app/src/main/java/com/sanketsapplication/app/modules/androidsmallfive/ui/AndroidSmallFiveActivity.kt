package com.sanketsapplication.app.modules.androidsmallfive.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.base.BaseActivity
import com.sanketsapplication.app.databinding.ActivityAndroidSmallFiveBinding
import com.sanketsapplication.app.modules.androidsmallfive.`data`.model.SpinnerGroupEightyThreeModel
import com.sanketsapplication.app.modules.androidsmallfive.`data`.viewmodel.AndroidSmallFiveVM
import com.sanketsapplication.app.modules.androidsmallseven.ui.AndroidSmallSevenActivity
import com.sanketsapplication.app.modules.androidsmallsix.ui.AndroidSmallSixActivity
import kotlin.String
import kotlin.Unit

class AndroidSmallFiveActivity :
    BaseActivity<ActivityAndroidSmallFiveBinding>(R.layout.activity_android_small_five) {
  private val viewModel: AndroidSmallFiveVM by viewModels<AndroidSmallFiveVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupEightyThreeList.value = mutableListOf(
    SpinnerGroupEightyThreeModel("Item1"),
    SpinnerGroupEightyThreeModel("Item2"),
    SpinnerGroupEightyThreeModel("Item3"),
    SpinnerGroupEightyThreeModel("Item4"),
    SpinnerGroupEightyThreeModel("Item5")
    )
    val spinnerGroupEightyThreeAdapter =
    SpinnerGroupEightyThreeAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupEightyThreeList.value?:
    mutableListOf())
    binding.spinnerGroupEightyThree.adapter = spinnerGroupEightyThreeAdapter
    binding.androidSmallFiveVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnRegister.setOnClickListener {
      val destIntent = AndroidSmallSevenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLoginNow.setOnClickListener {
      val destIntent = AndroidSmallSixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANDROID_SMALL_FIVE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AndroidSmallFiveActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
