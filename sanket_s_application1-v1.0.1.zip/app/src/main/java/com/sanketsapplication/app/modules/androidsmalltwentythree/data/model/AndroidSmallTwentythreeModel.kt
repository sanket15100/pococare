package com.sanketsapplication.app.modules.androidsmalltwentythree.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallTwentythreeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtInsuranceProfi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_insurance_profi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPolicyNumber: String? = MyApp.getInstance().resources.getString(R.string.lbl_policy_number)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMobileNo: String? = MyApp.getInstance().resources.getString(R.string.lbl_7659991543)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_name_of_insuran)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBAJAJAlliance: String? =
      MyApp.getInstance().resources.getString(R.string.msg_bajaj_alliance)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_insurance_amoun)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRs300000: String? = MyApp.getInstance().resources.getString(R.string.lbl_rs_3_00_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoverageamount: String? =
      MyApp.getInstance().resources.getString(R.string.msg_coverage_amount)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRs250000: String? = MyApp.getInstance().resources.getString(R.string.lbl_rs_2_50_000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_insurance_cover)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBasic: String? = MyApp.getInstance().resources.getString(R.string.lbl_basic)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMedicalProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_medical_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHospital: String? = MyApp.getInstance().resources.getString(R.string.lbl_hospital)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPharmacy: String? = MyApp.getInstance().resources.getString(R.string.lbl_pharmacy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtInsurance: String? = MyApp.getInstance().resources.getString(R.string.lbl_insurance)

)
