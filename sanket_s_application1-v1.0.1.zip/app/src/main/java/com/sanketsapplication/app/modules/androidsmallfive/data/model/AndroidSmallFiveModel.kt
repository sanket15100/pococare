package com.sanketsapplication.app.modules.androidsmallfive.`data`.model

import com.sanketsapplication.app.R
import com.sanketsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AndroidSmallFiveModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPoco: String? = MyApp.getInstance().resources.getString(R.string.lbl_poco)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStartyourjour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_start_your_jour)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTermAndCondition: String? =
      MyApp.getInstance().resources.getString(R.string.msg_by_registering)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAlreadyregiste: String? =
      MyApp.getInstance().resources.getString(R.string.msg_already_registe)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLoginNow: String? = MyApp.getInstance().resources.getString(R.string.lbl_login_now)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupThreeValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etEmailValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etMobileNoValue: String? = null
)
